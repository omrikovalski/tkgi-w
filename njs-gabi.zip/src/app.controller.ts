import { Controller, Get, UseGuards, Post } from '@nestjs/common';
import { AppService } from './app.service';
import { AuthGuard } from '@nestjs/passport';


 
@Controller('api/v1/info/mail')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  getHello2(): string {
    return this.appService.getHello();
  }
  
  
  @UseGuards(AuthGuard('jwt'))
  @Post("incomingMails")
  public  getIncomingMails() {
    return "Hello Mails"
}
}
